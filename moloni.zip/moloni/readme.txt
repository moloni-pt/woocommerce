NOTICE OF LICENSE
This file is licenced under the Software License Agreement.
With the purchase or the installation of the software in your application
you accept the licence agreement.

DISCLAIMER 
--------------------------------------
@author    Nuno Almeida
@copyright Moloni
@license   https://creativecommons.org/licenses/by-nd/4.0/  

Para qualquer d�vida sobre a instala��o/utiliza��o/melhorias do m�dulo n�o hesite em entrar em contacto
via telefone, webchat ou email.
https://moloni.com

Passos para a instala��o do Plugin Moloni para WooCommerce
Vers�o Plugin: 2

INSTALA��O
--------------------------------------
1� - Descompactar o ficheiro .zip
2� - Via FTP dever� colocar a pasta "moloni" na pasta "wp-content/plugins"  do seu website
3� - No backoffice ir ao menu Plugins -> Plugins instalados e activar o plugin "Moloni"
4� - Ir ao menu "Moloni" e fazer login com as credenciais da sua conta Moloni
5� - Carregar em "Op��es" e pode configurar o m�dulo a seu gosto para se adaptar � sua loja


NOTAS
--------------------------------------
- Pode obter uma listagem dos passos que tem que realizar para a instala��o do plugin na seguinte URL: http://plugins.moloni.com/woocommerce/
- Para utilizar o contribuinte, ter� que adicionar um plugin para permitir a inser��o do campo contribuinte. 
  Ir� ent�o ser criado um custom field, e no campo das op��es "Contribuinte", dever� seleccionar o custom field
  relativo ao campo do contribuinte. 

